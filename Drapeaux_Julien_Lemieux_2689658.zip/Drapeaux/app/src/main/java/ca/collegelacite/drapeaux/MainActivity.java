package ca.collegelacite.drapeaux;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {



    // Source de données pour l'adaptateur du ListView
    private ArrayList<Pays> listeDePays;

    //Adaptateur du listView
    private ArrayAdapter<Pays> adaptateur;

    //Position Pays Selectionné
    private int PaysSelectionner = 0;

    //Creer un nouveau pays
    Pays pays = new Pays();

    // Fonction du cycle de vie invoquée lors de la création de l'activité.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Récupérer les données source requises par l'adaptateur.

        listeDePays = Pays.lireDonnées( this );

        // ListView <---> adaptateur <---> données (listePays)
        adaptateur = new ArrayAdapter<Pays>(this, android.R.layout.simple_list_item_1, listeDePays);

        //ListView
        ListView listView = findViewById(R.id.PaysListView);
        listView.setAdapter(adaptateur);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                setPaysSelectionner(position);
            }

        });
        setPaysSelectionner(0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    protected void onSaveInstanceState(Bundle b){
        super.onSaveInstanceState(b);

        b.putInt("Position", getPaysSelectionner());
    }

    @Override
    protected void onRestoreInstanceState(Bundle b){
        super.onRestoreInstanceState(b);
        setPaysSelectionner(b.getInt("Position"));
    }

    private void afficherPays(Pays pays) {
        TextView tv = findViewById(R.id.PaystextView);
        tv.setText(pays.getNom());
        ImageView iv = findViewById(R.id.imagePays);
        pays.drapeauDansImageView(iv);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.Menu_wiki:
                Uri lien = Uri.parse(pays.getWikiUrl());
                Intent url = new Intent(Intent.ACTION_VIEW);
                url.setData(lien);
                startActivity(url);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public int getPaysSelectionner() {
        return PaysSelectionner;
    }

    public void setPaysSelectionner(int paysSelectionner) {
        this.PaysSelectionner = paysSelectionner;
        pays = listeDePays.get(this.PaysSelectionner);
        afficherPays(pays);
    }
}